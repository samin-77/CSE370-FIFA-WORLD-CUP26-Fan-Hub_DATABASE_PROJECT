const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5002;

// Middlewares
// CORS configuration for development and production
const allowedOrigins = [
  'http://localhost:5173',      // Local Vite dev server
  'http://127.0.0.1:5173',     // Alternative localhost
  'https://tact-iq-mrpi.vercel.app',  // Production frontend (Vercel)
  process.env.FRONTEND_URL     // Additional frontend URL from environment
].filter(Boolean);

// Also support comma-separated FRONTEND_URLS env var
if (process.env.FRONTEND_URLS) {
  process.env.FRONTEND_URLS.split(',').forEach(url => {
    const trimmed = url.trim();
    if (trimmed && !allowedOrigins.includes(trimmed)) {
      allowedOrigins.push(trimmed);
    }
  });
}

app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps, curl, etc.)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true
}));

app.use(express.json());

// Import Routes
const authRoutes = require('./routes/auth');
const standingsRoutes = require('./routes/standings');
const matchesRoutes = require('./routes/matches');
const statsRoutes = require('./routes/stats');
const fantasyRoutes = require('./routes/fantasy');
const bracketRoutes = require('./routes/bracket');
const quizRoutes = require('./routes/quiz');

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/standings', standingsRoutes);
app.use('/api/matches', matchesRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/fantasy', fantasyRoutes);
app.use('/api/bracket', bracketRoutes);
app.use('/api/quiz', quizRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'TactIQ API Server is running.' });
});

// Auto-migration: ensure quiz_attempts table exists
const { query: dbQuery } = require('./db');
async function ensureQuizAttemptsTable() {
  try {
    await dbQuery(`
      CREATE TABLE IF NOT EXISTS quiz_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        mode ENUM('rapid_fire', 'trivia', 'predictor') NOT NULL DEFAULT 'rapid_fire',
        score INT NOT NULL DEFAULT 0,
        correct_count INT DEFAULT 0,
        total_questions INT DEFAULT 0,
        time_taken INT DEFAULT 0,
        difficulty ENUM('easy', 'medium', 'hard', 'mixed') DEFAULT 'mixed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('quiz_attempts table ensured.');
  } catch (err) {
    console.error('Failed to ensure quiz_attempts table:', err.message);
  }
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Express Error Handler:', err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

// Start Server
app.listen(PORT, async () => {
  console.log(`TactIQ Server running on port ${PORT}`);
  await ensureQuizAttemptsTable();
});
